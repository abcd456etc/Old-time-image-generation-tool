import React, { useState } from 'react';
import { motion } from 'framer-motion';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../common/SafeIcon';

const { FiDownload, FiExternalLink, FiImage, FiAlertTriangle, FiLoader } = FiIcons;

const ThumbnailCard = ({ thumbnail, videoTitle, index }) => {
  const [imageLoaded, setImageLoaded] = useState(false);
  const [imageError, setImageError] = useState(false);
  const [downloading, setDownloading] = useState(false);

  const handleDownload = async () => {
    setDownloading(true);
    try {
      const response = await fetch(thumbnail.url);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      
      const link = document.createElement('a');
      link.href = url;
      link.download = `${videoTitle.replace(/[^a-zA-Z0-9]/g, '_')}-${thumbnail.quality}.jpg`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      // Clean up the blob URL
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Download failed:', error);
      // Fallback to direct link method
      const link = document.createElement('a');
      link.href = thumbnail.url;
      link.download = `${videoTitle.replace(/[^a-zA-Z0-9]/g, '_')}-${thumbnail.quality}.jpg`;
      link.target = '_blank';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } finally {
      setDownloading(false);
    }
  };

  const handleOpenInNewTab = () => {
    window.open(thumbnail.url, '_blank');
  };

  const getQualityColor = (quality) => {
    switch (quality) {
      case 'maxresdefault':
        return 'bg-green-100 text-green-800';
      case 'hqdefault':
        return 'bg-blue-100 text-blue-800';
      case 'mqdefault':
        return 'bg-yellow-100 text-yellow-800';
      case 'sddefault':
        return 'bg-orange-100 text-orange-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getQualityLabel = (quality) => {
    switch (quality) {
      case 'maxresdefault':
        return 'HD (1280x720)';
      case 'hqdefault':
        return 'HQ (480x360)';
      case 'mqdefault':
        return 'MQ (320x180)';
      case 'sddefault':
        return 'SD (640x480)';
      default:
        return quality;
    }
  };

  return (
    <motion.div
      whileHover={{ y: -5 }}
      className="bg-gray-50 rounded-xl overflow-hidden border border-gray-200 hover:border-red-300 transition-all duration-300 hover:shadow-lg"
    >
      <div className="relative aspect-video bg-gray-100">
        {!imageLoaded && !imageError && (
          <div className="absolute inset-0 flex items-center justify-center">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
            >
              <SafeIcon icon={FiImage} className="text-2xl text-gray-400" />
            </motion.div>
          </div>
        )}
        
        {imageError ? (
          <div className="absolute inset-0 flex items-center justify-center flex-col space-y-2">
            <SafeIcon icon={FiAlertTriangle} className="text-2xl text-gray-400" />
            <span className="text-sm text-gray-500">Image not available</span>
          </div>
        ) : (
          <img
            src={thumbnail.url}
            alt={`${thumbnail.quality} thumbnail`}
            className={`w-full h-full object-cover transition-opacity duration-300 ${
              imageLoaded ? 'opacity-100' : 'opacity-0'
            }`}
            onLoad={() => setImageLoaded(true)}
            onError={() => setImageError(true)}
            crossOrigin="anonymous"
          />
        )}
      </div>

      <div className="p-4">
        <div className="flex items-center justify-between mb-3">
          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getQualityColor(thumbnail.quality)}`}>
            {getQualityLabel(thumbnail.quality)}
          </span>
          
          <div className="flex items-center space-x-2">
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={handleOpenInNewTab}
              className="p-2 text-gray-600 hover:text-red-600 transition-colors"
              title="Open in new tab"
            >
              <SafeIcon icon={FiExternalLink} className="text-sm" />
            </motion.button>
            
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={handleDownload}
              disabled={imageError || downloading}
              className="p-2 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors min-w-[36px] flex items-center justify-center"
              title={downloading ? "Downloading..." : "Download"}
            >
              {downloading ? (
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                >
                  <SafeIcon icon={FiLoader} className="text-sm" />
                </motion.div>
              ) : (
                <SafeIcon icon={FiDownload} className="text-sm" />
              )}
            </motion.button>
          </div>
        </div>
        
        <div className="text-xs text-gray-500 space-y-1">
          <div>Format: JPEG</div>
          <div>Quality: {thumbnail.quality}</div>
        </div>
      </div>
    </motion.div>
  );
};

export default ThumbnailCard;