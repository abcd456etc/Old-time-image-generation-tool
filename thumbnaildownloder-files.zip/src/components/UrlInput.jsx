import React from 'react';
import { motion } from 'framer-motion';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../common/SafeIcon';

const { FiSearch, FiX, FiLoader } = FiIcons;

const UrlInput = ({ url, setUrl, onSubmit, onClear, isLoading, error }) => {
  return (
    <form onSubmit={onSubmit} className="space-y-4">
      <div className="relative">
        <input
          type="url"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="Paste YouTube video URL here... (e.g., https://www.youtube.com/watch?v=VIDEO_ID)"
          className={`w-full px-4 py-4 pr-24 text-lg border-2 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent transition-all ${
            error ? 'border-red-300 bg-red-50' : 'border-gray-200 bg-gray-50'
          }`}
          disabled={isLoading}
        />
        
        {url && (
          <motion.button
            type="button"
            onClick={onClear}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            className="absolute right-16 top-1/2 transform -translate-y-1/2 p-2 text-gray-400 hover:text-red-500 transition-colors"
          >
            <SafeIcon icon={FiX} className="text-lg" />
          </motion.button>
        )}
      </div>

      <motion.button
        type="submit"
        disabled={!url.trim() || isLoading}
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        className="w-full py-4 bg-red-600 text-white font-semibold rounded-xl hover:bg-red-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-all flex items-center justify-center space-x-2"
      >
        {isLoading ? (
          <>
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
            >
              <SafeIcon icon={FiLoader} className="text-lg" />
            </motion.div>
            <span>Extracting Thumbnails...</span>
          </>
        ) : (
          <>
            <SafeIcon icon={FiSearch} className="text-lg" />
            <span>Get Thumbnails</span>
          </>
        )}
      </motion.button>
    </form>
  );
};

export default UrlInput;