import React from 'react';
import { motion } from 'framer-motion';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../common/SafeIcon';

const { FiHeart, FiCode, FiInfo } = FiIcons;

const Footer = () => {
  return (
    <motion.footer
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.6, delay: 0.8 }}
      className="mt-16 py-8 border-t border-gray-200"
    >
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center space-x-6 text-sm text-gray-600">
          <div className="flex items-center space-x-2">
            <SafeIcon icon={FiCode} className="text-red-600" />
            <span>Built with React & Tailwind CSS</span>
          </div>
          
          <div className="flex items-center space-x-2">
            <SafeIcon icon={FiInfo} className="text-blue-600" />
            <span>No data stored</span>
          </div>
        </div>
        
        <div className="flex items-center justify-center space-x-2 text-sm text-gray-500">
          <span>Made with</span>
          <SafeIcon icon={FiHeart} className="text-red-500" />
          <span>for the YouTube community</span>
        </div>
        
        <div className="text-xs text-gray-400">
          <p>This tool extracts publicly available YouTube thumbnails. No copyright infringement intended.</p>
        </div>
      </div>
    </motion.footer>
  );
};

export default Footer;