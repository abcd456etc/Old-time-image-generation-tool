import React, { useState } from 'react';
import { motion } from 'framer-motion';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../common/SafeIcon';
import UrlInput from './UrlInput';
import ThumbnailGrid from './ThumbnailGrid';
import { extractVideoId, generateThumbnailUrls } from '../utils/thumbnailUtils';

const { FiDownload, FiImage, FiAlertCircle, FiLoader } = FiIcons;

const ThumbnailDownloader = ({ isLoading, setIsLoading }) => {
  const [url, setUrl] = useState('');
  const [thumbnails, setThumbnails] = useState([]);
  const [error, setError] = useState('');
  const [videoTitle, setVideoTitle] = useState('');
  const [downloadingAll, setDownloadingAll] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    try {
      const videoId = extractVideoId(url);
      if (!videoId) {
        throw new Error('Invalid YouTube URL. Please enter a valid YouTube video URL.');
      }

      const thumbnailUrls = generateThumbnailUrls(videoId);
      setThumbnails(thumbnailUrls);
      setVideoTitle(`YouTube Video (${videoId})`);
      
      // Simulate loading time for better UX
      await new Promise(resolve => setTimeout(resolve, 1000));
      
    } catch (err) {
      setError(err.message);
      setThumbnails([]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleClear = () => {
    setUrl('');
    setThumbnails([]);
    setError('');
    setVideoTitle('');
  };

  const handleDownloadAll = async () => {
    setDownloadingAll(true);
    
    try {
      for (const thumbnail of thumbnails) {
        try {
          const response = await fetch(thumbnail.url);
          const blob = await response.blob();
          const url = window.URL.createObjectURL(blob);
          
          const link = document.createElement('a');
          link.href = url;
          link.download = `${videoTitle.replace(/[^a-zA-Z0-9]/g, '_')}-${thumbnail.quality}.jpg`;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          
          window.URL.revokeObjectURL(url);
          
          // Small delay between downloads
          await new Promise(resolve => setTimeout(resolve, 300));
        } catch (error) {
          console.error(`Failed to download ${thumbnail.quality}:`, error);
          // Fallback method
          const link = document.createElement('a');
          link.href = thumbnail.url;
          link.download = `${videoTitle.replace(/[^a-zA-Z0-9]/g, '_')}-${thumbnail.quality}.jpg`;
          link.target = '_blank';
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
        }
      }
    } catch (error) {
      console.error('Download all failed:', error);
    } finally {
      setDownloadingAll(false);
    }
  };

  return (
    <div className="space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
        className="bg-white rounded-2xl shadow-lg p-8"
      >
        <UrlInput
          url={url}
          setUrl={setUrl}
          onSubmit={handleSubmit}
          onClear={handleClear}
          isLoading={isLoading}
          error={error}
        />
      </motion.div>

      {error && (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-red-50 border border-red-200 rounded-xl p-4 flex items-center space-x-3"
        >
          <SafeIcon icon={FiAlertCircle} className="text-red-500 text-lg flex-shrink-0" />
          <p className="text-red-700">{error}</p>
        </motion.div>
      )}

      {thumbnails.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="bg-white rounded-2xl shadow-lg p-8"
        >
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-3">
              <SafeIcon icon={FiImage} className="text-2xl text-red-600" />
              <div>
                <h2 className="text-2xl font-bold text-gray-800">Available Thumbnails</h2>
                <p className="text-gray-600">{videoTitle}</p>
              </div>
            </div>
            
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={handleDownloadAll}
              disabled={downloadingAll}
              className="flex items-center space-x-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors min-w-[140px] justify-center"
            >
              {downloadingAll ? (
                <>
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                  >
                    <SafeIcon icon={FiLoader} className="text-sm" />
                  </motion.div>
                  <span>Downloading...</span>
                </>
              ) : (
                <>
                  <SafeIcon icon={FiDownload} className="text-sm" />
                  <span>Download All</span>
                </>
              )}
            </motion.button>
          </div>

          <ThumbnailGrid thumbnails={thumbnails} videoTitle={videoTitle} />
        </motion.div>
      )}
    </div>
  );
};

export default ThumbnailDownloader;