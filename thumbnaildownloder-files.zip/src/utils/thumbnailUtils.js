export const extractVideoId = (url) => {
  const regex = /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/|youtube\.com\/v\/|youtube\.com\/watch\?.*&v=)([^&\n?#]+)/;
  const match = url.match(regex);
  return match ? match[1] : null;
};

export const generateThumbnailUrls = (videoId) => {
  const baseUrl = 'https://img.youtube.com/vi';
  
  const thumbnailQualities = [
    {
      quality: 'maxresdefault',
      url: `${baseUrl}/${videoId}/maxresdefault.jpg`,
      description: 'Maximum resolution (1280x720)'
    },
    {
      quality: 'hqdefault',
      url: `${baseUrl}/${videoId}/hqdefault.jpg`,
      description: 'High quality (480x360)'
    },
    {
      quality: 'mqdefault',
      url: `${baseUrl}/${videoId}/mqdefault.jpg`,
      description: 'Medium quality (320x180)'
    },
    {
      quality: 'sddefault',
      url: `${baseUrl}/${videoId}/sddefault.jpg`,
      description: 'Standard definition (640x480)'
    },
    {
      quality: 'default',
      url: `${baseUrl}/${videoId}/default.jpg`,
      description: 'Default (120x90)'
    },
    {
      quality: '0',
      url: `${baseUrl}/${videoId}/0.jpg`,
      description: 'Full size thumbnail'
    }
  ];

  return thumbnailQualities;
};

export const isValidYouTubeUrl = (url) => {
  const regex = /^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.be)\/.+/;
  return regex.test(url);
};