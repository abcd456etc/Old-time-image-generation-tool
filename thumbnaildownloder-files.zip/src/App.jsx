import React, { useState } from 'react';
import { motion } from 'framer-motion';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from './common/SafeIcon';
import ThumbnailDownloader from './components/ThumbnailDownloader';
import Header from './components/Header';
import Footer from './components/Footer';

const { FiYoutube } = FiIcons;

function App() {
  const [isLoading, setIsLoading] = useState(false);

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 via-white to-red-50">
      <div className="container mx-auto px-4 py-8">
        <Header />
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-4xl mx-auto"
        >
          <div className="text-center mb-12">
            <motion.div
              initial={{ scale: 0.8 }}
              animate={{ scale: 1 }}
              transition={{ duration: 0.5 }}
              className="inline-flex items-center justify-center w-20 h-20 bg-red-100 rounded-full mb-6"
            >
              <SafeIcon icon={FiYoutube} className="text-3xl text-red-600" />
            </motion.div>
            
            <h1 className="text-4xl md:text-5xl font-bold text-gray-800 mb-4">
              YouTube Thumbnail
              <span className="text-red-600"> Downloader</span>
            </h1>
            
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Extract and download high-quality thumbnails from any YouTube video. 
              Simply paste the video URL and choose your preferred quality.
            </p>
          </div>

          <ThumbnailDownloader isLoading={isLoading} setIsLoading={setIsLoading} />
        </motion.div>
        
        <Footer />
      </div>
    </div>
  );
}

export default App;